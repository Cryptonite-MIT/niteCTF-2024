To build: docker build -t chal .
To run: docker run -p 3000:80 -e ADMIN_USERNAME=admin -e ADMIN_PASSWORD=fake_password_dont_try_to_brute chal

If you get permission error try restarting the container.
